// Import the necessary modules from Playwright and local test utilities/fixtures
const { test, expect } = require('@playwright/test');
import {TALK_SHOP_URL} from '../../contants'; // Base URL of the shop
import { builCardDetails } from '../../fixtures/cards'; // Utility to build random card details
import {getAddress} from '../../fixtures/addresses'; // Utility to fetch addresses
import { buildEmail } from '../../fixtures/user'; // Utility to generate a unique email
import { parseToDecimal } from '../../utils/cleaners'; // Helper function to parse strings to decimal
import casual from 'casual'; // Library for generating random data

// Define a test for a new user's ability to buy from a show
test('As a new user, I should be able to buy from a show', async ({ page }) => {
  // Set a longer timeout for the test due to its complexity and network interactions
  test.setTimeout(60 * 1000);

  // Navigate to the base URL of the shop
  await page.goto(TALK_SHOP_URL);

  // Select a show from the homepage carousel
  const carousel = await page.locator('.alice-carousel').first(); // Locate the first carousel element
  await carousel.scrollIntoViewIfNeeded(); // Ensure the carousel is visible by scrolling to it
  await carousel.locator('li.alice-carousel__stage-item', {hasText: 'Test collector'}).first().click(); // Click the first carousel item containing 'Test collector'
  
  // Confirm redirection to the show page and check if the 'Shop' tab is visible
  await expect(page.url()).toContain('/watch/'); // Assert that the page's URL contains '/watch/'
  const shopTag = await page.getByRole('tab', {name: "Shop"}); // Locate the 'Shop' tab
  expect(shopTag).toBeVisible(); // Check that the 'Shop' tab is visible
  await page.getByRole('button', {name: 'Add to cart'}).first().click(); // Add the first item to the cart

  // Navigate to checkout
  await page.getByRole('link', {name: 'checkout'}).click(); // Click the 'checkout' link to go to the checkout page
  await expect(page.url()).toContain('/checkout'); // Verify that the URL contains '/checkout'
  
  // Fill in the checkout form
  const email = buildEmail('leo'); // Generate a unique email for the test
  await page.getByPlaceholder('Email address').fill(email); // Fill in the email address
  await page.getByText('Save & Continue').click(); // Click 'Save & Continue' to move to the next section

  // Wait for the 'Add shipping address' section to become visible
  await page.getByText('Add shipping address').waitFor({state: 'visible'});
  
  // Select the country from the dropdown if available, or get the pre-filled country
  const countrySelect = await page.getByText('Select Country', {exact: true}); // Locate the 'Select Country' dropdown
  let country; // Variable to store the selected or detected country
  if((await countrySelect.count()) > 0) { // Check if the country selection dropdown is present
    // If a country needs to be selected:
    await countrySelect.click(); // Open the dropdown
    const selection = page.getByRole('listbox').locator('.Select-option').first(); // Select the first option
    country = await selection.textContent(); // Retrieve the text content of the selected option
  } else {
    // If the country is pre-filled:
    country = await page.locator('#react-select-2--value-item > div').textContent(); // Get the pre-filled country text
  }
  await expect(country).not.toBeNull(); // Assert that a country has been selected or detected

  // Fill in the rest of the address form using random or provided data
  const address = getAddress(country); // Fetch an address for the selected or detected country
  const {first_name, last_name} = casual; // Generate random first and last names
  const fullName = `${first_name} ${last_name}`; // Combine names to form the full name

  // Fill in personal and address details
  await page.getByPlaceholder('First name').fill(first_name);
  await page.getByPlaceholder('Last name').fill(last_name);
  await page.getByPlaceholder('Street and number, P.O. box, c/o.').fill(address.street);
  await page.getByPlaceholder('City').fill(address.city);
  await page.getByText('State', {exact: true}).click(); // Open the state dropdown
  await page.getByRole('listbox').getByRole('option').filter({hasText: address.state}).click(); // Select the state
  await page.getByPlaceholder('Zip/Postal Code').fill(address.postalCode); // Fill in the ZIP code
  await page.getByPlaceholder('Mobile number').fill("+12814561234"); // Fill in a mock mobile number
  await page.getByText('Save & Continue').click(); // Proceed to the next section

  // Payment section
  const paymentMethodSelector = `div:text("Add payment method")`; // Selector for the 'Add payment method' section
  await page.waitForSelector(paymentMethodSelector); // Wait for the payment section to appear
  const card = builCardDetails(); // Generate random card details
  await page.getByPlaceholder('Name on card').fill(fullName); // Fill in the cardholder's name
  await page.getByPlaceholder('Card number').fill(card.cardNumber); // Fill in the card number
  await page.getByPlaceholder('MM').fill(card.month); // Fill in the expiration month
  await page.getByPlaceholder('YY').fill(card.year); // Fill in the expiration year
  await page.locator('[data-test-hint="CardCVC-input-1"]').fill(card.secureCode); // Fill in the CVC
  await page.locator('a:text("Save & Continue")').click(); // Click 'Save & Continue' to move to the next section

  // Validate the details in the review section
  const shippingAddress = `${address.street}, ${address.city}, ${address.stateAbbr} ${address.postalCode}`; // Construct the complete shipping address string
  const emailSelector = `span:text("${email}")`; // Selector for the email address span
  const fullNameSelector = `div:text("${fullName}")`; // Selector for the full name div
  const shippingAddressSelector = `div:text("${shippingAddress}")`; // Selector for the shipping address div
  
  // Wait for the selectors and validate their presence
  await page.waitForSelector(fullNameSelector);
  await page.waitForSelector(emailSelector);
  await page.waitForSelector(shippingAddressSelector);
  expect(await page.locator(fullNameSelector).count()).toBeGreaterThanOrEqual(1); // Ensure the full name is present
  expect(await page.locator(shippingAddressSelector).count()).toBeGreaterThanOrEqual(1); // Ensure the shipping address is present
  expect(await page.locator(emailSelector).count()).toBeGreaterThanOrEqual(1); // Ensure the email address is present

  // Validate the totals in the order summary
  const subTotal = parseToDecimal(await page.locator('span:right-of(span:has-text("Sub total"))').first().textContent()); // Parse the subtotal
  const taxes = parseToDecimal(await page.locator('span:right-of(span:has-text("Taxes"))').first().textContent()); // Parse the taxes
  const shipping = parseToDecimal(await page.locator('span:right-of(span:has-text("Shipping"))').first().textContent()); // Parse the shipping cost
  const processing = parseToDecimal(await page.locator('span:right-of(span:has-text("Processing"))').first().textContent()); // Parse the processing fee
  const total = parseToDecimal(await page.locator('span:right-of(span:has-text("Order total"))').first().textContent()); // Parse the total order cost
  expect(subTotal).not.toBe(NaN); // Ensure subtotal is a number
  expect(taxes).not.toBe(NaN); // Ensure taxes is a number
  expect(shipping).not.toBe(NaN); // Ensure shipping is a number
  expect(processing).not.toBe(NaN); // Ensure processing is a number
  expect(total).not.toBe(NaN); // Ensure total is a number

  const expectedTotal = parseFloat((subTotal + taxes + shipping + processing).toFixed(2)); // Calculate the expected total
  expect(expectedTotal).toEqual(total); // Compare the expected total with the calculated total

  // Finalize the order
  const button = await page.locator('a:text("Place order")').first(); // Locate the 'Place order' button
  await button.scrollIntoViewIfNeeded(); // Ensure the button is in the viewport
  expect(button).toBeInViewport(); // Check that the button is visible and in the viewport
  await button.click(); // Click the 'Place order' button to finalize the order

  // Confirm the order has been placed successfully
  const thanksSelector = `div:text("Thank you for your purchase!")`; // Selector for the thank you message
  await page.waitForSelector(thanksSelector); // Wait for the thank you message to appear
  const orderNumber = await page.locator('section.formRow').locator('div:below(div:text("Order Number"))').first().textContent(); // Retrieve the order number
  const confirmation = await page.getByText(`Confirmation for order ${orderNumber} will be sent to ${email}`); // Construct and find the confirmation text
  expect(await confirmation.count()).toEqual(1); // Ensure the confirmation text is present
  await expect(page.url()).toContain('/orders/'); // Verify that the user is redirected to the orders page
});
