// Import the Base class to extend its functionality
import Base from '../Base';

// Define the ProductsInventory class extending the Base class
class ProductsInventory extends Base {
    // Constructor to initialize the ProductsInventory page object
    constructor(page) {
        super(page); // Call the parent class (Base) constructor with the provided page object
    }

    /**
     * Navigates to the products inventory section of the website.
     *
     */
    async goPage() {
        // Click on the navigation icon (assumed to be an avatar) to open the user's channel or profile options
        await this._page.getByRole('navigation').locator('img[alt="Avatar image"]').click();
        // Click on the 'My Channel' link to go to the user's channel
        await this._page.locator('a', {hasText: "My Channel"}).click();
        // Click on the 'Products' link to navigate to the products inventory section
        await this._page.getByRole('link', {name: 'Products', exact: true}).click();
    }

    /**
     * Clicks the 'Add Product' button on the products inventory page.
     *
     * @return {Promise<void>} A promise that resolves after the button is clicked
     */
    async clickOnNew() {
        // Locate the 'Add Product' button and store it in a variable
        const addProductsBtn = await this._page.getByRole('link', {name: 'Add Product'});
        // Assert that the 'Add Product' button is enabled before clicking it
        await this._expect(addProductsBtn).toBeEnabled();
        // Click the 'Add Product' button to navigate to the product addition page
        await addProductsBtn.click();
    }

    /**
     * Deletes a product from the inventory.
     *
     * @param {string} name - The name of the product to delete
     */
    async deleteProduct(name) {
        // Locate the product row by finding a link with the product's name and then navigating up to the row level
        const productRow = this._page.locator('a', {hasText: name}).locator('..');
        // Find the delete icon (assumed to be represented by a trash can) within that product row
        const trashIcon = await productRow.locator('.fa-trash');
        // Click the delete icon to initiate the deletion process
        await trashIcon.click();
        // Confirm the deletion by clicking the 'Yes, Delete Product' button
        await this._page.getByRole('button', {name: 'Yes, Delete Product'}).click();
        // Wait for the deletion process to complete
        await this._page.waitForTimeout(2000);
        // Refresh the products list by clicking the 'Refresh Products' link
        await this._page.locator('a', {hasText: 'Refresh Products'}).click();
        // Wait for the refresh to complete and products to reappear
        await this._page.waitForTimeout(3000);
        // Verify that the product row is no longer present, ensuring the product was successfully deleted
        const rowCount = await productRow.count();
        await this._expect(rowCount).toBe(0);
    }

}

// Export the ProductsInventory class for use elsewhere
export default ProductsInventory;
