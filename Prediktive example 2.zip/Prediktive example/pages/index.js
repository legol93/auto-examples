// Import page model classes from their respective files
import Main from './main';
import ProductsInventory from './products/inventory';
import ProductsNew from './products/new';
import Product from './products/product';
import Checkout from './checkout';
import Orders from './orders';

/**
 * Constructs and returns page models for easier interaction with the pages in tests.
 *
 * @param {type} page - The Playwright page object, providing context for browser interaction.
 * @return {Object} An object containing instances of page models for main, productsInventory, productsNew, product, checkout, and orders.
 */
function buildPagesModels(page) {
    // Return an object with new instances of each page model, passing the Playwright page object to their constructors
    return {
        main: new Main(page),
        productsInventory: new ProductsInventory(page),
        productsNew: new ProductsNew(page),
        product: new Product(page),
        checkout: new Checkout(page),
        orders: new Orders(page)
    }
}

// Export the function for building page models to be used in other modules
export default buildPagesModels;
