// Import the Base class for inheritance
import Base from "../Base";

// Define the Orders class that extends the Base class
class Order extends Base {
    
    // Constructor initializes the class with a page object
    constructor(page) {
        super(page); // Pass the page object to the Base class constructor
    }

    /**
     * Waits for the orders page to load and checks for the presence of a thank you message.
     *
     * @return {Promise<void>} Resolves when the specific elements are detected on the page
     */
    async waitForOrdersPage() {
        // Define a selector for the 'Thank you for your purchase!' message
        const thanksSelector = `div:text("Thank you for your purchase!")`;
        // Wait for the selector to appear on the page, signifying that the order has been completed
        await this._page.waitForSelector(thanksSelector, {timeout: 20000});
        // Assert that the current URL contains '/orders/' to ensure we are on the orders page
        await this._expect(this._page.url()).toContain('/orders/');
    }

    /**
     * Confirms the details of an order by checking the presence of confirmation text.
     *
     * @param {string} email - The email address to check against the order confirmation details
     * @return {Promise<void>} Resolves when the order confirmation details have been successfully confirmed
     */
    async confirmOrderDetails(email) {
        // Locate and retrieve the order number from the page
        const orderNumber = await this._page.locator('section.formRow').locator('div:below(div:text("Order Number"))').first().textContent();
        // Construct and check for the presence of the confirmation text for the provided email and order number
        const confirmation = await this._page.getByText(`Confirmation for order ${orderNumber} will be sent to ${email}`);
        // Assert that the confirmation text exists exactly once on the page
        this._expect(await confirmation.count()).toEqual(1);
    }
}

// Export the Order class for use elsewhere
export default Order;
