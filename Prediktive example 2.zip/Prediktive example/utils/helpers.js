import { expect } from '@playwright/test';
/**
 * When having multiple tests that require login we can use this helper
 * @param {object} loginDetails 
 * @param {string} loginDetails.user 
 * @param {string} loginDetails.pwd
 * @param {object} page - playwright page object
 */
export async function login(loginDetails, page) {
    await page.locator('a:text("Sign In")').click();
    [
        'Google', 'Facebook', 'Apple'
    ].forEach(async(company) => {
        expect(await page.locator(`button:text("Sign in with ${company}")`).count()).toEqual(1)
    });

    await page.getByRole('textbox', {name: "email"}).fill(loginDetails.user);
    await page.getByRole('textbox', {name: 'password'}).fill(loginDetails.pwd);
    await page.getByRole('button', { name: 'Sign in', exact: true }).click();
}


export async function doesElementExist(page, locator) {
    await page.waitForSelector(locator);
    const element = await page.locator(locator);
    if((await element.count()) > 0) {
        return false
    }
    throw new Error(`${locator} does not exist`);
}
