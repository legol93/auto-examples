// Import the 'expect' function from the @playwright/test package for assertions
import { expect } from '@playwright/test';

// Define the base class for all page objects
class Base {
    _page;       // Declare a private field '_page' to hold the Playwright page object
    _expect;     // Declare a private field '_expect' to hold the expect function for assertions

    // Constructor initializes the class with the Playwright page object
    constructor(page) {
        this._page = page;       // Assign the passed page object to the private field '_page'
        this._expect = expect;   // Assign the 'expect' function to the private field '_expect'
    }
}

// Export the Base class to be used in other modules
export default Base;
