// Import the Base class to extend it
import Base from '../Base';

// Define the Checkout class extending the Base class
class Checkout extends Base {

    // Constructor to initialize the Checkout page object
    constructor(page) {
        super(page); // Call the parent class (Base) constructor
    }
    
    /**
     * Waits for the checkout page to be fully loaded and visible.
     */
    async waitForCheckoutPage() {
        // Wait for the URL to contain '/checkout', indicating that the checkout page is active
        await this._expect(this._page.url()).toContain('/checkout');
        // Define a selector for the checkout page address section and wait for it to be visible
        const checkoutAddressSelector = 'div:text("Checkout")';
        await this._page.waitForSelector(checkoutAddressSelector);
    }

    /**
     * Checks if a shipping method is already selected, if not, selects the first one.
     *
     * @return {Promise<void>}
     */
    async verifyOrSelectExistingShippingMethod() {
        // Wait a fixed time for potential page updates
        await this._page.waitForTimeout(3000);
        // Select the first available shipping method if it exists
        const shippingMethod = await this._page.locator('div[data-test-hint="ShippingMethod-div-1"]');
        if((await shippingMethod.count()) > 0) {
            await shippingMethod.first().click(); // Click the first shipping method
            await this._page.waitForTimeout(1000); // Wait for the selection to be processed
        }
    }

    /**
     * Clicks the button to place an order.
     *
     */
    async placeOrder() {
        // Find and click the 'Place order' button
        await this._page.getByText('Place order').last().click();
    }

}

// Export the Checkout class to be used in other modules
export default Checkout;
