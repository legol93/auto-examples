// Import the Base class to extend its functionalities
import Base from '../Base';
// Import a utility function doesElementExist for checking the existence of elements
import {doesElementExist} from '../../utils/helpers';

// Define the Product class extending the Base class
class Product extends Base {
    // Constructor initializes the class with a page object
    constructor(page) {
        super(page); // Pass the page object to the Base class constructor
    }

    /**
     * Validates the presence of product details on the product page.
     *
     * @param {Object} product - Contains details like name, price, and description to validate against
     */
    async validateProductDetails(product) {
        // Check if the product name, retail price, and description exist on the page
        await doesElementExist(this._page, `div:text("${product.name}")`);
        await doesElementExist(this._page, `div:text("$${product.retailPrice}")`);
        await doesElementExist(this._page, `div:text("${product.description}")`);
    }

    /**
     * Clicks the 'Add To Cart' button on the product page.
     */
    async addProductToCart() {
        // Find and click the 'Add To Cart' button
        await this._page.getByText('Add To Cart').click();
    }
}

// Export the Product class for use elsewhere
export default Product;
