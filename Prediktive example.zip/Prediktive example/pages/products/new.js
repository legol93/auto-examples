// Import the Base class for extension
import Base from '../Base';
// Import the 'casual' module for generating random data and 'path' for file path manipulations
import casual from 'casual';
import path from 'path';

// Define the ProductsNew class extending the Base class
class ProductsNew extends Base {
    // Constructor initializes the class with a page object
    constructor(page) {
        super(page); // Pass the page object to the Base class constructor
    }

    // Private method to click the 'Save Changes' button, used internally by this class
    async #clickSaveChanges() {
        // Locate the 'Save Changes' button and assert it is visible in the viewport
        const saveChangesBtn = await this._page.getByRole('button', {name: 'Save Changes'});
        await this._expect(saveChangesBtn).toBeInViewport();
        // Click the 'Save Changes' button to save the form data
        await saveChangesBtn.click();
    } 

    /**
     * Fills in the initial details for a new product and saves the changes.
     *
     * @param {Object} product - Object containing product details like name and price
     * @param {Array} categoriesSearch - Array of category names to choose from
     */
    async addInitialDetails(product, categoriesSearch) {
        // Fill in the product name, retail price, and description in their respective fields
        await this._page.getByPlaceholder('Product Name').fill(product.name);
        await this._page.locator('[name="retailPrice"]').fill(`${product.retailPrice}`);
        // Open the category picker, choose a random category, and select it
        await this._page.locator('[data-role="category-picker"]').click();
        const category = categoriesSearch[casual.integer(0, categoriesSearch.length - 1)];
        await this._page.getByRole('textbox', {name: 'search'}).fill(category);
        await this._page.locator(`[data-role="${category}"]`).click();
        // Fill in the product description
        await this._page.getByPlaceholder('Product Description').fill(product.description);
        // Click the 'Save Changes' button to save all entered details
        await this.#clickSaveChanges();
    }

    /**
     * Adds images and quantity for the new product and saves the changes.
     */
    async AddImageAndQuantity() {
        // Locate the 'Images' section and make sure it is in view
        const imagesContainer = await this._page.locator('div:text("Images")').locator('..').first();
        await imagesContainer.scrollIntoViewIfNeeded();
    
        // Assert that optional sections 'International Sales' and 'Variants' are visible
        await this._expect(this._page.locator('div:text("International Sales (Optional)")')).toBeVisible();
        await this._expect(this._page.locator('div:text("Variants (Optional)")')).toBeVisible();
    
        // Click the 'Image Upload' button
        await imagesContainer.getByText('Image Upload').click();

        // Set the file input to an image file path
        const imagepath = path.join(__dirname, '../../', '/assets/testing_image.jpeg');
        await imagesContainer.locator('input[type="file"]').last().setInputFiles(imagepath);
        // Click the 'Upload' button to upload the image
        await this._page.locator('input[value="Upload"]').click();
    
        // Fill in the quantity field with a random integer between 40 and 100
        const quantity = await this._page.locator('input[name="quantity"]');
        await quantity.scrollIntoViewIfNeeded();
        await quantity.fill(casual.integer(40, 100).toString());
        
        // Save the changes
        await this.#clickSaveChanges();
    } 

    /**
     * Adds a shipping method for the product and makes the product live.
     */
    async addShippingMethodAndGoLive() {
        // Open the shipping method selection modal
        await this._page.locator('button', {hasText: 'Add Shipping Method', exact: true}).click();
        // Wait for the modal options to become visible
        await this._page.waitForTimeout(3000);
        // Assert that the shipping method options are visible
        await this._expect(this._page.getByText('Ship on your own')).toBeVisible();
        await this._expect(this._page.getByText('Automated', {exact: true})).toBeVisible();
    
        // Select the 'Ship on your own' shipping method
        await this._page.getByText('Ship on your own').click();
        await this._page.waitForTimeout(1500); // Wait for the selection effects to occur
        // Assert that the 'Product Shipping Method' section is visible
        await this._expect(this._page.getByText('Product Shipping Method')).toBeVisible();
        
        // Assert that the 'flat_rate' input field is visible
        await this._expect(this._page.locator('input[name="flat_rate"]')).toBeVisible();
    
        // Try to click the 'Save' button and ensure it's enabled when appropriate conditions are met
        const saveButton = await this._page.getByRole('button', {name: 'Save'});
        await this._expect(saveButton).toBeDisabled(); // Initially, the save button should be disabled
    
        // Select a stock location to enable the 'Save' button
        await this._page.getByText('Select a stock location').click();
        await this._page.getByRole('listbox').locator('.Select-option').first().click();
        await this._expect(saveButton).toBeEnabled(); // Now, the save button should be enabled
        await saveButton.click(); // Click the now-enabled 'Save' button
    
        // Wait briefly for the save action to process
        await this._page.waitForTimeout(1000);
        // Click the 'Sell Live' button to make the product available for sale
       // await this._page.getByRole('button', {name: 'Sell Live'}).click();
    }

}

// Export the ProductsNew class for use elsewhere
export default ProductsNew;
