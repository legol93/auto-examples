/**
 * Builds a new email address based on the provided name and the current timestamp.
 * @param {string} name The base name for the email address.
 * @returns {string} email The newly generated email address.
 */
export function buildEmail(name) {
    // Return an email string combining the name, current timestamp, and a fixed domain
    return `${name}+${(new Date()).getTime()}@talkshop.live`
}

/**
 * Get seller details including username and password.
 * @returns {object} An object containing user and password fields.
 */
export function getSellerLoginDetails() {
    // Return an object with hardcoded login details for a seller
    return {
        user: 'SorryicantSharethis ',
        pwd: 'Thanks for not using this code'
    }
}
