// Import necessary modules and utilities
import { test } from '@playwright/test'; // Playwright test framework
import { getSellerLoginDetails } from '../../fixtures/user'; // Utility for fetching seller login details
import casual from 'casual'; // Library for generating random data
import buildPagesModels from '../../pages'; // Utility for creating page objects

// Define a set of categories to be used in the test
const categoriesSearch = ['Candle Making', 'Badge Software', 'Data Binders', 'Account Books'];

// Define a product object with random details to be used in the test
const product = {
    name: casual.sentence,
    description: casual.sentences(3),
    retailPrice: casual.integer(100, 300)
}

// Shorten the product name if it exceeds 50 characters
product.name = product.name.length > 50 ? product.name.slice(0, 40) : product.name;

// Fetch seller login credentials
const credentials = getSellerLoginDetails();

// Define a test for adding, buying, and deleting a product
test.only('As a loggedin user, I should be able to add a new product, buy it and delete it', async({page}) => {
    // Set a timeout for the test to accommodate longer operations
    test.setTimeout(45000);

    // Use the buildPagesModels utility to create instances of the required page objects
    const { 
        main, 
        productsInventory, 
        productsNew, 
        product: productPage, 
        checkout, 
        orders 
    } = buildPagesModels(page);

    // Go to the main page and perform login
    await main.go();
    await main.login(credentials);

    
    // Navigate to the products inventory and start the process to add a new product
    await productsInventory.goPage();
    await productsInventory.clickOnNew();

    // Fill in the initial product details and save them
    await productsNew.addInitialDetails(product, categoriesSearch);

    // Add images and set quantities for the new product
    await productsNew.AddImageAndQuantity();

    // Define shipping method and make the product available for sale
    await productsNew.addShippingMethodAndGoLive();

    // Search for the newly created product and navigate to its page
    await main.searchProductInNavBarAndGoToIt(product.name);

    // Validate the details of the product on its page
    await productPage.validateProductDetails(product);

    // Add the product to the shopping cart
    await productPage.addProductToCart();

    // Navigate to the checkout page
    await main.goToCheckout({assumeModalIsOpen: true});

    // Complete the checkout process
    await checkout.waitForCheckoutPage();
    await checkout.verifyOrSelectExistingShippingMethod();
    await checkout.placeOrder();

    // Wait for and confirm the details of the order
    await orders.waitForOrdersPage();
    await orders.confirmOrderDetails(credentials.user);

    // Navigate back to the products inventory and delete the product
    await productsInventory.goPage();
    await productsInventory.deleteProduct(product.name);
});
