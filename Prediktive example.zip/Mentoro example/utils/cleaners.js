/**
 * Parse an string to decimal
 * @param {string?} number 
 * @returns {decimal} number as decimal
 */
export function parseToDecimal(number) {
    if(!number) return NaN;
    return parseFloat(number?.replace('$','').replace('USD', ''));
}