// Import the Base class to extend functionality
import Base from '../Base';
// Import the constant TALK_SHOP_URL from the constants file, assuming it holds the base URL of the website
import {TALK_SHOP_URL} from '../../contants';

// Define the Main class extending the Base class
class Main extends Base {

    // Constructor to initialize the Main page object
    constructor(page) {
        super(page); // Call the parent class (Base) constructor with the provided page object
    }

    // Navigates to the main page of the application using the URL from constants
    async go() {
        await this._page.goto(TALK_SHOP_URL); // Use Playwright's goto method to navigate to the URL
    }

    /**
     * Performs a login operation using provided user credentials.
     *
     * @param {Object} loginDetails - Contains username and password for login
     * @return {Promise<void>} Resolves once the login operation is complete
     */
    async login(loginDetails) {
        // Click the 'Sign In' link
        await this._page.locator('a:text("Sign In")').click();
        // Check if sign in buttons for Google, Facebook, and Apple are present
        ['Google', 'Facebook', 'Apple'].forEach(async (company) => {
            this._expect(await this._page.locator(`button:text("Sign in with ${company}")`).count()).toEqual(1)
        });
    
        // Fill the email and password fields and click the sign-in button
        await this._page.getByRole('textbox', {name: "email"}).fill(loginDetails.user);
        await this._page.getByRole('textbox', {name: 'password'}).fill(loginDetails.pwd);
        await this._page.getByRole('button', { name: 'Sign in', exact: true }).click();
    }

/**
 * Searches for a product by typing into the search bar and navigating to the product page.
 *
 * @param {string} productName - The name of the product to search for
 * @param {number} delayInTyping - Optional delay between keystrokes when typing
 */
async searchProductInNavBarAndGoToIt(productName, delayInTyping = 100) {
    try {
        // Simulate typing the product name into the search field, with a delay if specified
        await this._page.getByPlaceholder('search').pressSequentially(productName, { delay: delayInTyping });

        // Check if a modal appears and close it if present
        const myShowsModal = await this._page.locator('[data-test-hint="StartShowModal-Link-1"]');
        if ((await myShowsModal.count()) > 0) {
            await myShowsModal.first().click();
        }

        // Click on the product name in the products wrapper to navigate to its page
        const productLink = await this._page.locator('#products-wrapper').getByText(productName);
        await productLink.click();
    } catch (error) {
        console.error("Error occurred while searching for and navigating to the product page:", error);
    }
}


    /**
     * Navigates to the checkout page.
     *
     * @param {Object} options - Contains options such as whether a modal is assumed to be open
     */
    async goToCheckout({assumeModalIsOpen}) {
        // If no modal is assumed to be open, click the button to open the cart
        if (!assumeModalIsOpen) {
            await this._page.locator('button[name="open-cart"]').click();
        }
        // Click the 'Checkout' link to navigate to the checkout page
        await this._page.getByRole('link', {name: 'Checkout'}).click();
    }
}

// Export the Main class to be used in other modules
export default Main;
