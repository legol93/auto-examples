// Import the 'casual' module for generating random data
import casual from 'casual';

// Define an array of mock card numbers for testing
const cards = [
    '4242424242424242',
    '4000056655665556',
    '2223003122003222',
    '6011111111111117',
    '6011981111111113',
    '3056930009020004',
    '3566002020360505',
    '6200000000000005'
]

/**
 * Builds card details using the 'casual' library for random data.
 * @returns {object} card Contains card number, secure code, month, and year.
 */
export function builCardDetails() {
    // Select a random card number from the predefined list
    const cardNumber = cards[Math.floor(casual.random * cards.length)];
    // Generate a random month between 1 and 12
    const month = casual.integer(1, 12);
    // Generate a future year (current year + 2)
    const year = (new Date()).getFullYear() + 2;

    // Return an object containing the generated card details
    return {
        cardNumber,
        secureCode: (casual.integer(0, 999)).toString().padEnd(3, '0'), // Generate a 3-digit security code, padded with zeros if necessary
        month: month.toString().padStart(2, '0'), // Ensure the month is two digits
        year: year.toString().slice(-2) // Return only the last two digits of the year
    }
}
