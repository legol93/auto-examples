// Define an array of address objects, each containing details for a different location
const addresses = [
  // Each object represents an address with keys for country, street, city, state, postalCode, and state abbreviation
  {
    country: "United Kingdom",
    street: "10 Downing St",
    city: "London",
    state: "Wenstminster",
    postalCode: "SW1A 2AA",
    stateAbbr: 'Wenstminster'
  },
  // Additional objects follow the same structure for different addresses
  {
    country: "United States",
    street: "3419 Crest Hill Ln",
    city: "Houston",
    state: "Texas",
    postalCode: "77007",
    stateAbbr: 'TX'
  },
  // Repeat for various locations
  {
    country: "United States",
    street: "950 N Harper Ave",
    city: "West Hollywood",
    state: "California",
    postalCode: "90046",
    stateAbbr: 'CA'
  },
  {
    country: "Alemania",
    street: "Scharnweberstrasse 58",
    city: "Mannheim Innenstadt",
    state: "Baden-Württemberg",
    postalCode: "68159",
    stateAbbr: 'Baden-Württemberg'
  },
  {
    country: "Canada",
    street: "3085 Glen Erin Dr",
    city: "Mississauga",
    state: "Ontario",
    postalCode: "L5L 1J3",
    stateAbbr: 'Ontario'
  }
];

/**
* Obtain an address based on the provided country.
* @param {string|null} country The country to match addresses against.
* @returns {object} address An address object if a matching country is found.
*/
export const getAddress = (country) => {
  // Filter the addresses array to only those that match the provided country
  const filter = addresses.filter((c) => c.country === country);
  // If more than one address matches, randomly select one to return
  if(filter.length > 1) {
      const index = Math.floor(Math.random() * filter.length)
      return filter[index];
  }
  // Otherwise, return the first (and only) matching address
  return filter[0];
}
